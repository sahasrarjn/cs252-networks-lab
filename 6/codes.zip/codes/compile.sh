gcc -o sender sender.c
gcc -o receiver receiver.c